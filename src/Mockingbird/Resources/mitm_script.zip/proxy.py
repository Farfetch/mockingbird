#!/usr/bin/env python3

import argparse
import asyncio
import queue
import json
import threading
import typing
import traceback
import sys
import struct
import websockets
from mitmproxy import ctx
from mitmproxy import http

def convert_headers_to_bytes(header_entry):
    return [bytes(header_entry[0], "utf8"), bytes(header_entry[1], "utf8")]

def convert_body_to_bytes(body):
    if body is None:
        return bytes()
    else:
        return body

def decode_body(url, content):
    
    body = ""
    parsed = True

    if len(content) > 0:
        try:
            body = content.decode("utf-8")
        except UnicodeDecodeError:        
            parsed = False    
            # print(">>> CONTENT EXCEPTION: " + str(url))

    return body, parsed

def is_text_response(headers):
    if 'content-type' in headers:
        ct = headers['content-type'].lower()
        # Allow all application/ and text/ MIME types.
        return 'application' in ct or 'text' in ct or ct.strip() == ""
    return True

class WebSocketAdapter:
    """
    Relays HTTP/HTTPS requests to a websocket server.
    Enables using MITMProxy from outside of Python.
    """

    def websocket_thread(self):
        """
        Main function of the websocket thread. Runs the websocket event loop
        until MITMProxy shuts down.
        """
        self.worker_event_loop = asyncio.new_event_loop()
        self.worker_event_loop.run_until_complete(self.websocket_loop())

    def __init__(self):
        self.queue = queue.Queue()
        self.intercept_paths = frozenset([])
        self.only_intercept_text_files = False
        self.finished = False
        # Start websocket thread
        threading.Thread(target=self.websocket_thread).start()

    def load(self, loader):
        loader.add_option(
            "intercept", str, "",
            """
            A list of HTTP paths, delimited by a comma.
            E.g.: /foo,/bar
            """
        )
        loader.add_option(
            name = "onlyInterceptTextFiles",
            typespec = bool,
            default = False,
            help = "If true, the plugin only intercepts text files and passes through other types of files",
        )
        return

    def configure(self, updates):
        if "intercept" in updates:
            self.intercept_paths = frozenset(ctx.options.intercept.split(","))
            # print("Intercept paths:")
            # print(self.intercept_paths)
        if "onlyInterceptTextFiles" in updates:
            self.only_intercept_text_files = ctx.options.onlyInterceptTextFiles
            # print("Only intercept text files:")
            # print(self.only_intercept_text_files)
        return

    def send_message(self, metadata, data1, data2):
        """
        Sends the given message on the WebSocket connection,
        and awaits a response. Metadata is a JSONable object,
        and data is bytes.
        """
        msg = json.dumps(metadata)

        obj = {
            'lock': threading.Condition(),
            'msg': msg,
            'response': None
        }

        obj['lock'].acquire()
        self.queue.put(obj)
        # print("waiting")
        obj['lock'].wait()
        # print("wait finished!")

        new_response = obj['response']
        if new_response is None:
            # print(">>> without response!")
            return None


        try:
            (json.loads(new_response))
        except:
            print(">>> new resp: " + new_response)

        return (json.loads(new_response))

    def responseheaders(self, flow):
        # Stream all non-text responses if only_intercept_text_files is enabled.
        # Do not stream intercepted paths.
        flow.response.stream = flow.request.path not in self.intercept_paths and self.only_intercept_text_files and not is_text_response(flow.response.headers)

    def response(self, flow):
        """
        Intercepts an HTTP response. Mutates its headers / body / status code / etc.
        """
        if flow.response.stream:
            return

        request = flow.request
        response = flow.response
        
        requestBody, parsed = decode_body(request.url, request.content)        
        if parsed == False:
            return

        responseBody, parsed = decode_body(request.url, response.content)
        if parsed == False:
            return

        # print(">>> status_code:" + response.status_code)
        # print(">>> responseBody:" + responseBody)

        message_response = self.send_message({
            'request': {
                'method': request.method,
                'url': request.url,
                'headers': list(request.headers.items(True)),
                'body': requestBody
            },
            'response': {
                'status_code': response.status_code,
                'headers': list(response.headers.items(True)),
                'body': responseBody
            }
        }, convert_body_to_bytes(request.content), convert_body_to_bytes(response.content))

        if message_response is None:
            # print(">>> message: NONE")
            return


        if message_response.get('response') is None:
            # print(">>> message RESPONSE: NONE")
            # print(">>> message URL: "  + str(request.url))
            return

        data_response = message_response['response']
        data_response_status = int(data_response['status_code'])
        data_response_headers = data_response['headers']
        data_response_body = data_response['body']

        # print(">>> data_response_headers: " + str(data_response_headers))
        # print(">>> data_response: " + str(data_response))
        # print(">>> data_url: " + str(request.url))
        # print(">>> data_response_status: " + str(data_response_status))
        # print(">>> data_response_body: " + data_response_body)

        flow.response = http.HTTPResponse.make(
            data_response_status,
            data_response_body,
            map(convert_headers_to_bytes, data_response_headers)
        )

        return

    def done(self):
        """
        Called when MITMProxy is shutting down.
        """
        # Tell the WebSocket loop to stop processing events
        self.finished = True
        self.queue.put(None)
        return

    async def websocket_loop(self):
        while not self.finished:
            try:
                async with websockets.connect('ws://localhost:5000/api/stream', max_size = None) as websocket:
                    while True:
                        # Make sure connection is still live.
                        await websocket.ping()
                        try:
                            obj = self.queue.get(timeout=1)
                            if obj is None:
                                break
                            try:
                                obj['lock'].acquire()
                                await websocket.send(obj['msg'])
                                obj['response'] = await websocket.recv()
                            finally:
                                # Always remember to wake up other thread + release lock to avoid deadlocks
                                obj['lock'].notify()
                                obj['lock'].release()
                        except queue.Empty:
                            pass

            except websockets.exceptions.ConnectionClosed:
                # disconnected from server
                pass
            except BrokenPipeError:
                # Connect failed
                pass
            except IOError:
                # disconnected from server mis-transfer
                pass
            except:
                print("Unexpected error:", sys.exc_info())
                traceback.print_exc(file=sys.stdout)

addons = [
    WebSocketAdapter()
]
